#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="${APP_DIR:-/opt/shoe-shop}"
DOMAIN="${DOMAIN:-}"
ADMIN_USERNAME="${ADMIN_USERNAME:-admin}"

if [[ "${EUID}" -ne 0 ]]; then echo "این اسکریپت را با root اجرا کن."; exit 1; fi
if [[ ! -f "$APP_DIR/app.py" ]]; then echo "app.py در $APP_DIR پیدا نشد؛ ابتدا مخزن را در این مسیر clone کن."; exit 1; fi
if [[ -z "$DOMAIN" ]]; then read -rp "دامنه سایت (مثلاً queli.example.com؛ برای فعلاً خالی بگذار): " DOMAIN; fi

read -rsp "رمز اولیه مدیر (حداقل ۱۰ کاراکتر): " ADMIN_PASSWORD; echo
if [[ ${#ADMIN_PASSWORD} -lt 10 ]]; then echo "رمز باید حداقل ۱۰ کاراکتر باشد."; exit 1; fi

apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y python3 python3-venv python3-pip nginx git
id -u www-data >/dev/null 2>&1 || useradd --system --no-create-home --shell /usr/sbin/nologin www-data
mkdir -p "$APP_DIR" /var/lib/queli-shop
chown -R www-data:www-data "$APP_DIR" /var/lib/queli-shop
python3 -m venv "$APP_DIR/venv"
"$APP_DIR/venv/bin/pip" install --upgrade pip
"$APP_DIR/venv/bin/pip" install -r "$APP_DIR/requirements.txt"

SECRET_KEY="$(python3 -c 'import secrets; print(secrets.token_hex(48))')"
cat > /etc/queli-shop.env <<ENV
SHOESHOP_DB=/var/lib/queli-shop/users.db
SECRET_KEY=$SECRET_KEY
ADMIN_USERNAME=$ADMIN_USERNAME
ADMIN_PASSWORD=$ADMIN_PASSWORD
COOKIE_SECURE=0
VAPID_SUBJECT=mailto:admin@${DOMAIN:-localhost}
ENV
chmod 600 /etc/queli-shop.env
unset ADMIN_PASSWORD

chown -R www-data:www-data "$APP_DIR" /var/lib/queli-shop
chmod 750 "$APP_DIR"

cat > /etc/systemd/system/shoe-shop.service <<SERVICE
[Unit]
Description=Queli Shop Flask Application
After=network.target

[Service]
User=www-data
Group=www-data
WorkingDirectory=$APP_DIR
EnvironmentFile=/etc/queli-shop.env
ExecStart=$APP_DIR/venv/bin/gunicorn --workers 2 --bind 127.0.0.1:8000 --timeout 120 app:app
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
SERVICE

cat > /etc/nginx/sites-available/queli-shop <<'NGINX'
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name _;
    client_max_body_size 110m;
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 120s;
    }
}
NGINX
ln -sfn /etc/nginx/sites-available/queli-shop /etc/nginx/sites-enabled/queli-shop
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl daemon-reload
systemctl enable --now shoe-shop
systemctl restart nginx

if [[ -n "$DOMAIN" ]]; then
  if ! command -v certbot >/dev/null 2>&1; then
    DEBIAN_FRONTEND=noninteractive apt-get install -y certbot python3-certbot-nginx
  fi
  certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos --register-unsafely-without-email --redirect
  sed -i 's/COOKIE_SECURE=0/COOKIE_SECURE=1/' /etc/queli-shop.env
  systemctl restart shoe-shop
fi

echo
echo "نصب کوئلی شاپ تمام شد."
echo "مسیر برنامه: $APP_DIR"
echo "دیتابیس: /var/lib/queli-shop/users.db"
echo "وضعیت سرویس: systemctl status shoe-shop --no-pager"
if [[ -z "$DOMAIN" ]]; then echo "برای SSL، دامنه را به IP سرور وصل کن و certbot --nginx -d YOUR_DOMAIN را اجرا کن."; fi
