#!/usr/bin/env bash
set -Eeuo pipefail
if [[ "$EUID" -ne 0 ]]; then echo "با root اجرا کن."; exit 1; fi
read -rp "آدرس مخزن GitHub (HTTPS یا SSH): " REPO_URL
if [[ -z "$REPO_URL" ]]; then echo "آدرس مخزن خالی است."; exit 1; fi
APP_DIR=/opt/shoe-shop
if [[ -e "$APP_DIR" ]]; then
  echo "$APP_DIR از قبل وجود دارد. برای جلوگیری از بازنویسی اطلاعات، نصب متوقف شد."
  exit 1
fi
git clone "$REPO_URL" "$APP_DIR"
read -rp "دامنه سایت (مثلاً queli.example.com؛ برای فعلاً خالی بگذار): " DOMAIN
export APP_DIR DOMAIN
bash "$APP_DIR/install.sh"
